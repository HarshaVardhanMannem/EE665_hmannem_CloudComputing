T
# app.js Blog API

This is a simple Express.js RESTful API for managing a blog system. It provides endpoints for creating, reading, updating, and deleting blog posts.

## Installation

1. Clone this repository.
2. Install dependencies using `npm install`.
3. Make sure you have MongoDB installed and running on your local machine.

## Configuration

1. Set up your MongoDB URI in the `uri` variable in `app.js`.
2. Ensure that MongoDB is running locally or provide the appropriate URI for your MongoDB instance.

## Running the Server

To start the server, run:

```
node app.js
```

The server will start running on port 3000 by default.

## API Endpoints

### GET /posts

- Retrieves all blog posts.

### POST /posts

- Adds a new blog post with a title, content, and username.

### GET /posts/user/:userName

- Retrieves all blog posts by a given username.

### GET /posts/title/:searchWord

- Retrieves all blog posts containing a given word in the title.

### GET /posts/content/:searchWord

- Retrieves all blog posts containing a given word in the content.

### DELETE /posts/user/:userName

- Deletes all blogs by a given username.

### DELETE /posts/content/:searchWord

- Deletes all blogs that contain a certain word in the content.

### GET /posts/count/:userName

- Returns the username and the number of blogs posted by that username.

## Usage

- Use any API testing tool like Postman or cURL to interact with the API endpoints.
- Ensure proper authentication and authorization mechanisms are implemented in a production environment.

