const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require("mongodb")
const app = express();
const PORT = 3000;
dbname = "Blog"

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// MongoDB URI
const uri = "mongodb://127.0.0.1"
const client = new MongoClient(uri)

// Function to connect to the MongoDB database
async function connectToDatabase() {
    try {
        await client.connect()
        console.log("Connected to MongoDB ...")
    } catch (error) {
        console.error(`error connecting to {database}`)
    }
}

// GET - /posts - Fetch all blog posts
app.get('/posts', async (req, res) => {
    await client.connect();
    db = client.db(dbname)
    const collection = db.collection('posts');
    try {
        const posts = await collection.find({}).toArray();
        res.json(posts);
        console.log("Fetched all the blog posts")
    client.close();
    } catch (err) {
        console.log(err);
        res.status(500).send("Failed to fetch posts.");
    }
});

// POST - /posts - Add a new blog post
app.post('/posts', async (req, res) => {
    // Check if request body exists and is not empty
    if (!req.body || Object.keys(req.body).length === 0) {
        return res.status(400).send('Request body is empty or not valid JSON.');
    }

    await client.connect();
    db = client.db(dbname)
    const collection = db.collection('posts');

    try {
        const result = await collection.insertOne(req.body);
        if (result.acknowledged) {
            res.status(200).json({ 'Message': 'Post added successfully' });
            console.log("Added the new blog post successfully")
        } else {
            res.status(400).send('Adding new post failed');
        }
        client.close();
    } catch (err) {
        console.log(err);
        res.status(500).send('Adding new post failed');
    }
});

// GET - /posts/user/:userName - Retrieve all blog posts by a given username
app.get('/posts/user/:userName', async (req, res) => {
    try {
        await client.connect();
        db = client.db(dbname)
        const userName = req.params.userName;
        const collection = db.collection('posts');
        const posts = await collection.find({ Username: userName }).toArray();
        res.json(posts);
        console.log("All the blog posts added by the "+{userName}+ "are fetched")
        console.log(posts)
        client.close();
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// GET - /posts/title/:searchWord - Retrieve all blog posts containing a given word in the title
app.get('/posts/title/:searchWord', async (req, res) => {
    try {
        const searchWord = req.params.searchWord;
        await client.connect();
        const db = client.db(dbname);
        const collection = db.collection('posts');

        const posts = await collection.find({ Title: { $regex: searchWord, $options: 'i' } }).toArray();
        res.json(posts);
        console.log("Blogs containing the given keyword of title are fetched");

        client.close();
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// GET - /posts/content/:searchWord - Retrieve all blog posts containing a given word in the content
app.get('/posts/content/:searchWord', async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbname);
        const searchWord = req.params.searchWord;
        const collection = db.collection('posts');

        const posts = await collection.find({ Content: { $regex: searchWord, $options: 'i' } }).toArray();
        res.json(posts);
        console.log("Blogs containing the given keyword in content are fetched")

        client.close();
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// DELETE - /posts/user/:userName - Delete all blogs by a given username
app.delete('/posts/user/:userName', async (req, res) => {
    try {
        const userName = req.params.userName;
        await client.connect();
        const db = client.db(dbname);
        const collection = db.collection('posts');

        const result = await collection.deleteMany({ Username: userName });
        res.json({ message: `${result.deletedCount} post(s) deleted` });

        client.close();
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// DELETE - /posts/content/:searchWord - Delete all blogs that contain a certain word in the content
app.delete('/posts/content/:searchWord', async (req, res) => {
    try {
        const searchWord = req.params.searchWord;
        await client.connect();
        const db = client.db(dbname);
        const collection = db.collection('posts');

        const result = await collection.deleteMany({ Content: { $regex: searchWord, $options: 'i' } });
        res.json({ message: `${result.deletedCount} post(s) deleted` });

        client.close();
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// GET - /posts/count/:userName - Returns the username and the number of blogs posted by that username
app.get('/posts/count/:userName', async (req, res) => {
    try {
        await client.connect();
        const db = client.db(dbname);
        const userName = req.params.userName;
        const collection = db.collection('posts');
        
        // Counting the number of posts by the given username
        const count = await collection.countDocuments({ Username: userName });
        
        res.json({ userName, postCount: count });
        
        client.close();
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Start the Express server
app.listen(PORT, async () => {
    console.log(`Connected to the Express server on port ${PORT}`)
    await connectToDatabase()
});
