# app.js Blog API

## Overview

This is a RESTful API for managing a blog system built with Express.js. It provides endpoints for creating, reading, updating, and deleting blog posts.

## Base URL

The base URL for all endpoints is `http://localhost:3000`.

## Endpoints

### Retrieve all blog posts

- **URL**: `/posts`
- **Method**: `GET`
- **Description**: Retrieves all blog posts.
- **Response**: 
  - `200 OK`: A list of blog posts.

### Add a new blog post

- **URL**: `/posts`
- **Method**: `POST`
- **Description**: Adds a new blog post with a title, content, and username.
- **Request Body**: 
  ```json
  {
    "title": "string",
    "content": "string",
    "username": "string"
  }
  ```
- **Response**:
  - `200 OK`: Post added successfully.
  - `400 Bad Request`: Adding new post failed.

### Retrieve all blog posts by username

- **URL**: `/posts/user/:userName`
- **Method**: `GET`
- **Description**: Retrieves all blog posts by a given username.
- **Path Parameters**:
  - `userName`: The username of the author.
- **Response**:
  - `200 OK`: A list of blog posts by the specified user.

### Delete all blogs by username

- **URL**: `/posts/user/:userName`
- **Method**: `DELETE`
- **Description**: Deletes all blogs by a given username.
- **Path Parameters**:
  - `userName`: The username of the author.
- **Response**:
  - `200 OK`: Number of posts deleted.

### Retrieve all blog posts containing a word in the title

- **URL**: `/posts/title/:searchWord`
- **Method**: `GET`
- **Description**: Retrieves all blog posts containing a given word in the title.
- **Path Parameters**:
  - `searchWord`: The word to search for in the title.
- **Response**:
  - `200 OK`: A list of blog posts containing the specified word in the title.

### Retrieve all blog posts containing a word in the content

- **URL**: `/posts/content/:searchWord`
- **Method**: `GET`
- **Description**: Retrieves all blog posts containing a given word in the content.
- **Path Parameters**:
  - `searchWord`: The word to search for in the content.
- **Response**:
  - `200 OK`: A list of blog posts containing the specified word in the content.

### Delete all blogs containing a word in the content

- **URL**: `/posts/content/:searchWord`
- **Method**: `DELETE`
- **Description**: Deletes all blogs containing a certain word in the content.
- **Path Parameters**:
  - `searchWord`: The word to search for in the content.
- **Response**:
  - `200 OK`: Number of posts deleted.

### Get the number of blogs posted by username

- **URL**: `/posts/count/:userName`
- **Method**: `GET`
- **Description**: Returns the number of blogs posted by a given username.
- **Path Parameters**:
  - `userName`: The username of the author.
- **Response**:
  - `200 OK`: Number of posts by the specified user.
