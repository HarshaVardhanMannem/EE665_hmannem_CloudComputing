# IoT Device Management System

This Node.js application allows you to manage IoT devices by providing endpoints to register new devices, display registered devices, receive data from devices, and send commands to devices.

## Setup

1. Clone the repository:
git clone <repository-url>
2. Install dependencies:
npm install
npm install express (TO install express framework)

3. Start the server:
npm app 


4. Access the application in your browser at `http://localhost:3000`.

## Usage

- Register a new device:
- Endpoint: POST `/register`
- Request Body:


- Display all registered devices:
- Endpoint: GET `/show`

- Receive data from a device:
- Endpoint: POST `/data`
- Request Body:


- Send a command to a device:
- Endpoint: POST `/command`
- Request Body:







