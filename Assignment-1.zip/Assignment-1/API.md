Below is the API documentation for  Node.js application:

---

# IoT Device Management System API Documentation

## Register a New Device

Registers a new device with a unique `deviceId` and `deviceType`.

- **URL:** `/register`
- **Method:** `POST`
- **Request Body:**
  ```json
  {
    "deviceId": "string",
    "deviceType": "string"
  }
  ```
- **Success Response:**
  - **Code:** 201 CREATED
    **Content:** `{ "message": "Device registered successfully" }`
- **Error Response:**
  - **Code:** 409 CONFLICT
    **Content:** `{ "error": "Device ID already exists" }`
  - **Code:** 400 BAD REQUEST
    **Content:** `{ "error": "Device ID and Device Type are required" }`
  - **Code:** 500 INTERNAL SERVER ERROR
    **Content:** `{ "error": "Failed to register device" }`

## Display All Registered Devices

Displays all registered devices.

- **URL:** `/show`
- **Method:** `GET`
- **Success Response:**
  - **Code:** 200 OK
    **Content:** 
    ```json
    [
      { "deviceId": "string", "deviceType": "string" },
      ...
    ]
    ```
- **Error Response:**
  - **Code:** 500 INTERNAL SERVER ERROR
    **Content:** `{ "error": "Failed to retrieve devices" }`

## Receive Data from Device

Receives data from a device.

- **URL:** `/data`
- **Method:** `POST`
- **Request Body:**
  ```json
  {
    "deviceId": "string",
    "data": "string"
  }
  ```
- **Success Response:**
  - **Code:** 200 OK
    **Content:** `{ "message": "Data received successfully" }`
- **Error Response:**
  - **Code:** 400 BAD REQUEST
    **Content:** `{ "error": "Both deviceId and data are required" }`

## Send Command to Device

Sends a command to a device.

- **URL:** `/command`
- **Method:** `POST`
- **Request Body:**
  ```json
  {
    "deviceId": "string",
    "command": "string"
  }
  ```
- **Success Response:**
  - **Code:** 200 OK
    **Content:** `{ "message": "Command sent successfully" }`
- **Error Response:**
  - **Code:** 400 BAD REQUEST
    **Content:** `{ "error": "Both deviceId and command are required" }`

---

This API documentation provides detailed information about the endpoints, their request bodies, and possible responses, including error handling. It can help users understand how to interact with your IoT Device Management System.