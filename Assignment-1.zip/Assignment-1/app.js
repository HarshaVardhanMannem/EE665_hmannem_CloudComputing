const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const port = 3000;

const bodyParser = require('body-parser');


const devicesFilePath = path.join(__dirname +"/"+ "public" + "/"+ "devices.json");

let devices = [];

// Read the file using a relative path
try {
  const data = fs.readFileSync(devicesFilePath);
  const devices = JSON.parse(data);
} catch (err) {
  console.error('Error reading devices file:', err);
}


let existing_devices = loadDevices();
// Function to load existing devices from devices.json
function loadDevices() {
try {
  const data = fs.readFileSync(devicesFilePath);
  return JSON.parse(data);
} catch (err) {
  console.error('Error reading devices file:', err);
  return [];
}
}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


app.use(express.json());

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Get method to display the Webpage index.html

app.get('/index.html', function (req, res) {
    res.sendFile(__dirname + "/" + "index.html");
})


// Function to log activities with timestamps to logs.txt file
function logData(activity, details) {

  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] ${activity}: ${details}\n`;

  const logsFilePath = path.join(__dirname +"/"+ "public" + "/", 'logs.txt');

  fs.appendFile(logsFilePath, logEntry, (err) => {
    if (err) {
      console.error('Error writing to logs file:', err);
    }
  });
}

module.exports = logData;


// Endpoint to register new devices
app.post('/register', (req, res) => {

    var response = {
        deviceId : req.body.deviceId,  
        deviceType : req.body.deviceType
    }
    
    // Storing deviceId and deviceType in below variables 

    let deviceId = req.body.deviceId;
    let deviceType = req.body.deviceType;
 
  // Check for duplicate device ID
  if (devices.find(device => device.deviceId === deviceId)) {
    return res.status(409).send('Device ID already exists');
  }

  // Add new device
  devices.push({ deviceId, deviceType });

  // Write updated devices array to devices.json file
  fs.writeFile(devicesFilePath, JSON.stringify(devices, null, 2), (err) => {
    if (err) {
      console.error('Error writing to devices file:', err);
      return res.status(500).json({ error: 'Failed to register device' });
    }

    res.setHeader('Content-Type', 'text/html');
    res.status(201).send('<h1>'+"Device registered successfully"+'</h1>');
  });
  
  // Logging the data to the logs.txt for the device registering task
  
  logData('Registration', JSON.stringify(req.body));

});

app.get('/show', (req, res) => {
    try {
      // Read devices from devices.json
      const data = fs.readFileSync(devicesFilePath);
      const devices = JSON.parse(data);
      if (devices.length === 0) {
        return res.status(404).json({ error: 'No devices registered' });
      }
      res.json(devices);
      logData('Show devices', res.json(devices));
    } catch (err) {
      console.error('Error reading devices file:', err);
      res.status(500).json({ error: 'Failed to retrieve devices' });
    }
  });


// Endpoint to receive device data
app.post('/data', (req, res) => {
  const { deviceId, data } = req.body;

  
  // Checking of the device ID exist so that we can send a data to it
  if (devices.find(device => device.deviceId === deviceId))
  { 
    // Ensure deviceId and data are present in the request body
    if (!deviceId || !data) {
      return res.status(400).json({ error: 'Both deviceId and data are required' });
    }
    
    // Log the received data with a timestamp
    const timestamp = new Date().toISOString();
  
    console.log(`Received data from device ${deviceId} at ${timestamp}:`, data);
  
    logData('Received Data', JSON.stringify(req.body));
  
    res.status(200).json({ message: 'Data received successfully' });

  }
  else{
    res.status(400).json({message:' Device ID doesnt exist'})
  }
});


app.post('/command', (req, res) => {
  const { deviceId, command } = req.body;

  // Checking of the device ID exist so that we can send a command to it
  if (devices.find(device => device.deviceId === deviceId))
  {

  // Validate the presence of deviceId and command in the request body
  if (!deviceId || !command) {
    return res.status(400).json({ error: 'Both deviceId and command are required' });
  }

  logData('Sent Command', JSON.stringify(req.body));

  // Log the command with a timestamp
  const timestamp = new Date().toISOString();
  console.log(`Command sent to device ${deviceId} at ${timestamp}:`, command);

  // Respond with a confirmation message
  res.status(200).json({ message: 'Command sent successfully' });
}
else{
    res.status(400).json({message:' Device ID doesnt exist'})
}
});

app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);

   // Check if existing devices array is not empty
   if (existing_devices.length > 0) {
    console.log('Existing devices are loaded from devices.json:');
    console.log(existing_devices);
  } else {
    console.log('No existing devices found in devices.json.');
}
});
